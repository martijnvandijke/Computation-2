find src lccdir lib \( -name '*.c' -o -name '*.h' -o -name '*.md' \) -exec dos2ux.sh {} \;
