/*
 * wctype.h
 * ANSI/ISO 9899-1990 Normative Addendum 1.
 */

#if	!defined(__WCTYPE_H__)
#define	__WCTYPE_H__

typedef	int	wint_t;
typedef	int	wctype_t;

#if	defined(__cplusplus)
extern	"C"	{
}
#endif	/* defined(__cplusplus) */

#endif	/* !defined(__WCHAR_H__) */

/* end of wctype.h */
