/*
 * common/_null.h
 * Common definition of NULL.
 */

#if	!defined(NULL)

#define	NULL	0

#endif	/* !defined(NULL) */


