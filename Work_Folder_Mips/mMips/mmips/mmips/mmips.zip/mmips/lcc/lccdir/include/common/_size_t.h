/*
 * common/_size_t.h
 * Common definition of size_t.
 */

#ifndef	__COMMON__SIZE_T_H__
#define	__COMMON__SIZE_T_H__

typedef	unsigned int	size_t;

#endif	/* __COMMON__SIZE_T_H__ */
