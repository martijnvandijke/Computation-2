/*
 * lib-src/ansi/ctype/isdigit.c
 * ANSI/ISO 9899-1990, Section 7.3.1.4.
 *
 * int isdigit(int c)
 */

#include <ctype.h>

int
(isdigit)(int c)
{
	return isdigit(c);
}
