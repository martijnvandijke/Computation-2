/*
 * lib-src/ansi/ctype/isupper.c
 * ANSI/ISO 9899-1990, Section 7.3.1.10.
 *
 * int isupper(int c)
 */

#include <ctype.h>

int
(isupper)(int c)
{
	return isupper(c);
}
