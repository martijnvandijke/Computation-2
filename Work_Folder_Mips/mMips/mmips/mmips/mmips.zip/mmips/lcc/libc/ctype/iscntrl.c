/*
 * lib-src/ansi/ctype/iscntrl.c
 * ANSI/ISO 9899-1990, Section 7.3.1.3.
 *
 * int iscntrl(int c)
 */

#include <ctype.h>

int
(iscntrl)(int c)
{
	return iscntrl(c);
}
