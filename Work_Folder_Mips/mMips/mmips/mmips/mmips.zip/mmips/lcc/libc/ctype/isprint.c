/*
 * lib-src/ansi/ctype/isprint.c
 * ANSI/ISO 9899-1990, Section 7.3.1.7.
 *
 * int isprint(int c)
 */

#include <ctype.h>

int
(isprint)(int c)
{
	return isprint(c);
}
