/*
 * lib-src/ansi/ctype/isalnum.c
 * ANSI/ISO 9899-1990, Section 7.3.1.1.
 *
 * int isalnum(int c)
 */

#include <ctype.h>

int
(isalnum)(int c)
{
	return isalnum(c);
}
