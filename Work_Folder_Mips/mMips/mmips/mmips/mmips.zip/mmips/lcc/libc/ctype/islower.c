/*
 * lib-src/ansi/ctype/islower.c
 * ANSI/ISO 9899-1990, Section 7.3.1.6.
 *
 * int islower(int c)
 */

#include <ctype.h>

int
(islower)(int c)
{
	return islower(c);
}
