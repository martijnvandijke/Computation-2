void bzero(char *p, int n)
{
	memset(p, 0, n);
}
