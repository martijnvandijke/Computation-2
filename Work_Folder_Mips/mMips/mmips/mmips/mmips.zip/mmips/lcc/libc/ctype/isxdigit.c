/*
 * lib-src/ansi/ctype/isxdigit.c
 * ANSI/ISO 9899-1990, Section 7.3.1.11.
 *
 * int isxdigit(int c)
 */

#include <ctype.h>

int
(isxdigit)(int c)
{
	return isxdigit(c);
}
