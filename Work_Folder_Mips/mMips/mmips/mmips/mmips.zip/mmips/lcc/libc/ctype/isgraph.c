/*
 * lib-src/ansi/ctype/isgraph.c
 * ANSI/ISO 9899-1990, Section 7.3.1.5.
 *
 * int isgraph(int c)
 */

#include <ctype.h>

int
(isgraph)(int c)
{
	return isgraph(c);
}
