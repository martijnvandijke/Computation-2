/*
 * lib-src/ansi/ctype/ispunct.c
 * ANSI/ISO 9899-1990, Section 7.3.1.8.
 *
 * int ispunct(int c)
 */

#include <ctype.h>

int
(ispunct)(int c)
{
	return ispunct(c);
}
