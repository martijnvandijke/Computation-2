/*
 * lib-src/ansi/ctype/isalpha.c
 * ANSI/ISO 9899-1990, Section 7.3.1.2.
 *
 * int isalpha(int c)
 */

#include <ctype.h>

int (isalpha)(int c)
{
	return isalpha(c);
}
