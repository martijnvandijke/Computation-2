/*
 * lib-src/ansi/ctype/isspace.c
 * ANSI/ISO 9899-1990, Section 7.3.1.9.
 *
 * int isspace(int c)
 */

#include <ctype.h>

int
(isspace)(int c)
{
	return isspace(c);
}
